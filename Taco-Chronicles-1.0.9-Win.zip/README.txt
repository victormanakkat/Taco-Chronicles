Taco Chronicles v1.0.9
======================

Goal 
You are Dr. Taco and want to take over the world! All you have is your awesome costume and a weapon. 
Use the arrow keys to run through the level, jump, and shoot at oncoming monsters. The farther you get, 
the bigger and better weapons you receive! And then eat Taco's to unlock even more goodies!

Download
Most likely you have already downloaded the Taco Chronicles since you are reading this file. But if you
haven't, go to pywarecode.github.io/Taco-Chronicles and click on the "Download" button.

Install
Once you have downloaded the Taco Chronicles, move the .zip package to a safe location out of the downloads
folder. Then, extract the .zip and delete the .zip (But keep the extracted part). Enter the extracted folder
and right click over the exe called "The Taco Chronicles". Go to the "Send To" menu and click on desktop.
Go to the desktop and double click on the shortcut. Accept the license, or read the complete LICENSE.txt file,
and the game will start.

Play
To play the Taco Chronicles, you use the arrow keys to walk and jump. Press the space to shoot, and use the
mouse to click on the different buttons. As you play and shoot more monsters, you will unlock new weapons.

Weapons Chart
9mm:              0 points needed to unlock
Shotgun:      10000 points needed to unlock
AK-47:        15000 points needed to unlock
Bazooka:      30000 points needed to unlock
Flamethrower: 35000 points needed to unlock